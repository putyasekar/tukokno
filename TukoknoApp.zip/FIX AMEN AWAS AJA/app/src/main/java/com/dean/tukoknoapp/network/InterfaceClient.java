package com.dean.tukoknoapp.network;

import com.dean.tukoknoapp.model.ResponseLogin;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface InterfaceClient {
    @FormUrlEncoded
    @POST("exec")
    Call<ResponseLogin> login
            (@Field(value = "sheetName", encoded = true) String sheetName,
             @Field(value = "action", encoded = true) String login,
             @Field(value = "email", encoded = true) String email,
             @Field(value = "password", encoded = true) String password);
//
//    @FormUrlEncoded
//    @POST("exec")
//    Call<ResponseRegister> registerSiswa
//            (@Field(value = "sheetName", encoded = true) String sheetName,
//             @Field(value = "action", encoded = true) String insert,
//             @Field(value = "kodeSiswa", encoded = true) String kodeSiswa,
//             @Field(value = "namaSiswa", encoded = true) String namaSiswa,
//             @Field(value = "password", encoded = true) String password,
//             @Field(value = "emailSiswa", encoded = true) String emailSiswa,
//             @Field(value = "alamatSiswa", encoded = true) String alamatSiswa,
//             @Field(value = "noTelp", encoded = true) String noTelp);
}
