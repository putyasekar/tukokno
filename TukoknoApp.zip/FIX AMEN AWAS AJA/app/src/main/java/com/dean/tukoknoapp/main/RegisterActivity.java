package com.dean.tukoknoapp.main;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;

import com.dean.tukoknoapp.R;
import com.dean.tukoknoapp.network.InterfaceClient;
import com.dean.tukoknoapp.network.RetrofitConfig;

public class RegisterActivity extends AppCompatActivity {
    EditText etCode, etName, etPassword, etConfirmPass, etEmail, etAlamat, etTelepon;
    Button btnRegister;
    ProgressDialog loading;

    Context context;
    InterfaceClient interfaceClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        context = this;
        interfaceClient = RetrofitConfig.createService(InterfaceClient.class);

        data();
    }

    private void data() {

    }
}
