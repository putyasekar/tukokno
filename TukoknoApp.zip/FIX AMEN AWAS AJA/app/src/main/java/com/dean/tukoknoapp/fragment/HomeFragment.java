package com.dean.tukoknoapp.fragment;


import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.dean.tukoknoapp.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends Fragment {


    LinearLayout llLokasi, llGenre, llEvent;
    TextView tvLokasi, tvGenre, tvEvent;


    public HomeFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_home, container, false);

        llLokasi = v.findViewById(R.id.linear_lokasi);
        llGenre = v.findViewById(R.id.linear_genre);
        llEvent = v.findViewById(R.id.linear_event);
        tvLokasi = v.findViewById(R.id.tv_lokasi);
        tvGenre = v.findViewById(R.id.tv_genre);
        tvEvent = v.findViewById(R.id.tv_event);

        tvLokasi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                llGenre.setVisibility(View.GONE);
                llEvent.setVisibility(View.GONE);
                llLokasi.setVisibility(View.VISIBLE);
            }
        });

        tvGenre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                llGenre.setVisibility(View.VISIBLE);
                llEvent.setVisibility(View.GONE);
                llLokasi.setVisibility(View.GONE);
            }
        });

        tvEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                llGenre.setVisibility(View.GONE);
                llEvent.setVisibility(View.VISIBLE);
                llLokasi.setVisibility(View.GONE);
            }
        });

        return v;
    }

}
